/**
  ****************************(C) COPYRIGHT 2024 HzMi****************************
  * @file       BSP_FILTER_CAN.c/h
  * @brief      
  * @note       
  * @history
  *  Version    Date            Author          Modification
  *  V1.0.0     Apr-8-2024     ���Ʊ�              1. done
  *
  @verbatim
  ==============================================================================

  ==============================================================================
  @endverbatim
  ****************************(C) COPYRIGHT 2024 HzMi****************************
  */
#ifndef __BSP_FILTER_CAN_H__
#define __BSP_FILTER_CAN_H__
#include "struct_typedef.h"


extern void CAN_FILTER_Init(void);

#endif
