.h文件
1. - can.h（can1和can2配置相同，全部打开）
2. - main.h
3. - CAN_Tx_Rx_4.h（四电机通用版）
4. - CAN_Tx_Rx_7.h（七电机试用版）
5. - struct_typedef.h
6. - BSP_FILTER_CAN.h

.c文件
1. - can.c
2. - BSP_FILTER_CAN.c
3. - CAN_Tx_Rx_4.c
4. - CAN_Tx_Rx_7.c



注意,3,4文件不能同时用。5文件需在int main（）中初始化完CAN后再初始化即可打开CAN
CAN_Cmd_Chassis(int16_t motor1, int16_t motor2, int16_t motor3, int16_t motor4)，
主函数调用此函数输入电流即可转动